package collections;

public class Pizzas {

}
