package diskpizza.lib.models;

public class Distributor {

}
