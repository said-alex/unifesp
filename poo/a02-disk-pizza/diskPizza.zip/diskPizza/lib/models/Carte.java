package diskpizza.lib.models;

public class Carte {

}
